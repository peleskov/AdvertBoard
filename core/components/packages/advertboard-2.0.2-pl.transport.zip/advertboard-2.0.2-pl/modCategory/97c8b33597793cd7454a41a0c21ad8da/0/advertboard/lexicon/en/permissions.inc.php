<?php
/**
 * Russian permissions Lexicon Entries for AdvertBoard
 *
 * @package AdvertBoard
 * @subpackage lexicon
 */
$_lang['advertboard_save'] = 'Permission for save/update data.';