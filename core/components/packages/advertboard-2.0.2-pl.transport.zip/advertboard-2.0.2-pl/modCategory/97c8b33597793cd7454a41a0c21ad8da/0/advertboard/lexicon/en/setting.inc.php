<?php

$_lang['area_advertboard_main'] = 'Main';

$_lang['setting_advertboard_some_setting'] = 'Some setting';
$_lang['setting_advertboard_some_setting_desc'] = 'This is description for some setting';