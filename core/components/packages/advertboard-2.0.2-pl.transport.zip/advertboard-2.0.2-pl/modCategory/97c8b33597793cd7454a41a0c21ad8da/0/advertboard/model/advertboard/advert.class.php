<?php
/**
 * @package advertboard
 */
class Advert extends xPDOSimpleObject {}