<?php

$_lang['area_advertboard_main'] = 'Основные';

$_lang['setting_advertboard_some_setting'] = 'Какая-то настройка';
$_lang['setting_advertboard_some_setting_desc'] = 'Это описание для какой-то настройки';