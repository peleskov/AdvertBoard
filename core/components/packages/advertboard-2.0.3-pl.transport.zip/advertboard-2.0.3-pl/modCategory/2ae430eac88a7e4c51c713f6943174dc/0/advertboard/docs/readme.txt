--------------------
AdvertBoard
--------------------
Authors:
    Sergei Peleskov <info@s1temaker.ru>
--------------------

Advert Board for MODx Revolution.

