<?php
/**
 * English permissions Lexicon Entries for AdvertBoard
 *
 * @package AdvertBoard
 * @subpackage lexicon
 */
$_lang['advertboard_save'] = 'Разрешает создание/изменение данных.';