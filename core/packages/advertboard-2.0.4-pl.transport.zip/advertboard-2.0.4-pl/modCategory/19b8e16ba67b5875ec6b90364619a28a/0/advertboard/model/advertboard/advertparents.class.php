<?php
class AdvertParents extends xPDOSimpleObject {}