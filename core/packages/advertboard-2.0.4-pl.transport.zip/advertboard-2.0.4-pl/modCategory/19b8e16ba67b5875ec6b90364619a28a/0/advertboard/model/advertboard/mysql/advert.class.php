<?php
require_once (dirname(__DIR__) . '/advert.class.php');
class Advert_mysql extends Advert {}